# Manifest

## 交付文档

- `README.md`
- `docs/00-original-question-and-answer.md`
- `docs/01-compact-implementation.md`
- `docs/02-gap-and-portability.md`
- `docs/03-refactor-plan.md`
- `docs/04-file-mapping.md`
- `docs/05-test-and-ablation.md`

## 上游参考快照

- `upstream-claude-code-best/src/services/compact/`：20 个实现与测试文件。
- `upstream-claude-code-best/src/services/SessionMemory/`：会话记忆相关实现与测试。
- `upstream-claude-code-best/src/query.ts`：主循环接入。
- `upstream-claude-code-best/src/services/claude-api-integration.ts`：API Context Management 接入，原文件为 `src/services/api/claude.ts`。
- `upstream-claude-code-best/src/utils/`：Boundary、Token、Context、Beta 与 SessionStart 支撑文件。
- `upstream-claude-code-best/src/constants/betas.ts`。

## CoStrict 当前实现快照

- Condense、Folded File Context 及现有测试。
- Context Management、Sliding Window 及现有测试。
- Task 主循环接入。
- Message Manager/Rewind 接入。
- OutputInterceptor 与 ReadCommandOutputTool。
- Context Management 与 Global Settings 类型。
- 默认 Support Prompt。

## 不包含内容

- 未修改的 CoStrict 完整仓库。
- 上游完整仓库及其构建依赖。
- Anthropic 未公开的 Beta Header、服务端实现或官方私有源码。
- 可直接应用的生产补丁。实施前应按 `docs/03-refactor-plan.md` 分阶段开发和验证。

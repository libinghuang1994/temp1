# CoStrict Compact 改造资料包

本资料包用于参考 `claude-code-best/claude-code` 的 Compact 实现，设计 CoStrict 的下一代上下文压缩机制。资料包不直接修改 CoStrict 生产代码，内容包括：

- 上游 Compact 模块及关键接入代码快照；
- CoStrict 当前 Condense、上下文管理、命令输出治理与测试快照；
- 源码级实现分析、逐文件映射和分阶段改造方案；
- 测试、消融实验、灰度指标与验收标准。

## 建议阅读顺序

1. `docs/00-original-question-and-answer.md`：查看原问题和当时的完整回答。
2. `docs/01-compact-implementation.md`：理解参考实现的完整调用链。
3. `docs/02-gap-and-portability.md`：明确 CoStrict 已有能力、缺口和不可直接移植项。
4. `docs/03-refactor-plan.md`：按阶段实施改造。
5. `docs/04-file-mapping.md`：定位上游文件与 CoStrict 目标文件。
6. `docs/05-test-and-ablation.md`：验证压缩比、信息保留和任务成功率。

## 推荐目标架构

```text
工具结果预算化/落盘
        ↓
Observation Masking（保留协议骨架）
        ↓
动态阈值与下一轮增长预判
        ↓
模型生成结构化 Summary
        ↓
Compact Boundary + Summary + Recent Tail
        ↓
规则、文件、Skill、Plan、任务状态确定性重注入
        ↓
压缩质量检查与防 Thrashing
```

## 资料来源

- 上游仓库：<https://github.com/claude-code-best/claude-code>
- 上游快照 commit：`34b3dc99bf40c57c0b78f3b5b1d70471ebc2d06d`
- 上游版本提交：`chore: v2.8.4`，2026-07-21
- CoStrict 快照来源：本工作区 `costrict-deploy/frontend-source`

## 重要边界

上游仓库明确说明其为逆向/反编译并扩展的社区复原项目，只能作为工程参考，不能视为 Anthropic 官方 Claude Code 内部实现的完整证明。仓库还包含未公开 Beta、内部 Feature Flag 和实验路径；本方案对这些能力采用可替代设计，不要求 CoStrict 依赖私有接口。

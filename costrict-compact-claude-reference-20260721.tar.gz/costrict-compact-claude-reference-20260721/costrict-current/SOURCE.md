# CoStrict 当前实现快照说明

来源目录：`/home/hlb/costrict_v1/costrict-deploy/frontend-source`

本目录仅保存与上下文压缩直接相关的当前代码和测试快照，用于做差异分析；不参与 CoStrict 构建，也不是建议直接覆盖回源码树的补丁。

主要入口：

- `src/core/context-management/index.ts`
- `src/core/condense/index.ts`
- `src/core/condense/foldedFileContext.ts`
- `src/core/Task.ts`（原 `src/core/task/Task.ts`）
- `src/integrations/terminal/OutputInterceptor.ts`
- `src/core/ReadCommandOutputTool.ts`
- `src/core/message-manager.ts`
- `src/shared/support-prompt.ts`
- `packages/types/src/global-settings.ts`


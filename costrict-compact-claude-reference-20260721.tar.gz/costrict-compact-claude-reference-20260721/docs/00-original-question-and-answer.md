# 原问题与回答：Claude Code 如何实现上下文压缩

## 用户问题

> [claude-code-best/claude-code](https://github.com/claude-code-best/claude-code) 根据这个告诉我claude code是怎么实现的上下文压缩

## 当时的回答

结论：这个仓库实现的是“分层压缩”，并非简单调用模型总结一次。

```text
工具结果轻量清理
        ↓
Token 阈值判断
        ↓
调用模型生成结构化摘要
        ↓
摘要替换历史对话
        ↓
确定性重注入文件、规则、Skill、Plan 等上下文
```

需要注意：该仓库自述为逆向/反编译后的社区复原版，并包含额外功能，因此能说明其当前实现，但不能证明 Anthropic 官方内部实现完全一致。[仓库说明](https://github.com/claude-code-best/claude-code)

### 1. 第一层：工具结果清理

API 请求可以携带 `context_management`：

- 默认在输入达到约 180K Token 时触发。
- 目标是至少清除约 140K Token，使上下文回落到约 40K。
- 主要清理 Bash、Read、Grep、Glob、WebSearch、WebFetch 等工具的旧结果。
- 这是规则/API 侧清理，不需要模型生成摘要。

参数可以通过 `API_MAX_INPUT_TOKENS` 和 `API_TARGET_INPUT_TOKENS` 修改。[apiMicrocompact.ts](https://github.com/claude-code-best/claude-code/blob/main/src/services/compact/apiMicrocompact.ts)

仓库还存在 Cached Microcompact：

- 工具结果超过 10 个时触发。
- 保留最近 5 个，删除更早的结果。
- 通过缓存编辑避免破坏 Prompt Cache。

但这个社区版本缺少未公开的 Cache Editing Beta Header，且默认构建未启用该 Feature，因此通常不会生效。

### 2. 第二层：自动压缩触发

有效上下文窗口为：

\[
W_{effective}=W_{model}-\min(MaxOutputTokens,20000)
\]

自动压缩阈值为：

\[
T_{compact}=W_{effective}-Buffer
\]

Buffer 根据窗口大小变化：

- 小于 400K：13K
- 400K～800K：30K
- 800K 以上：50K

例如 200K 窗口、预留 20K 输出：

\[
T=200K-20K-13K=167K
\]

`CLAUDE_AUTOCOMPACT_PCT_OVERRIDE` 可以提前触发，但源码使用 `Math.min`，因此不能把阈值提高到默认安全线之上。[autoCompact.ts](https://github.com/claude-code-best/claude-code/blob/main/src/services/compact/autoCompact.ts)

### 3. 第三层：调用模型生成摘要

标准 `/compact` 和 Auto Compact 都会调用模型：

- 使用当前主循环模型 `mainLoopModel`，不是固定的小模型。
- 默认尝试创建一个单轮 Fork Agent，共享原对话的 Prompt Cache。
- 摘要 Agent 禁止调用工具。
- 最大摘要输出约 20K Token。
- 缓存共享失败后，改用普通流式模型调用。
- 普通回退路径关闭 Thinking。

送给摘要模型前还会：

- 只保留最后一个 `compact_boundary` 之后的对话。
- 将图片、文档替换为 `[image]`、`[document]`。
- 删除压缩后会重新注入的 Skill Listing 等附件。
- 修复工具调用与工具结果之间的协议结构。

[compact.ts](https://github.com/claude-code-best/claude-code/blob/main/src/services/compact/compact.ts)

### 4. 摘要保留什么

摘要 Prompt 强制模型整理九类信息：

1. 用户主要请求和意图
2. 技术概念
3. 文件、代码段和修改
4. 错误及修复
5. 问题解决过程
6. 所有用户消息
7. 未完成任务
8. 当前正在进行的工作
9. 下一步

模型先输出 `<analysis>` 和 `<summary>`，随后程序删除 `<analysis>`，只把格式化后的 Summary 放回上下文。[prompt.ts](https://github.com/claude-code-best/claude-code/blob/main/src/services/compact/prompt.ts)

### 5. 压缩后的上下文结构

压缩完成后，模型实际看到的是：

```text
compact_boundary
+ synthetic user summary
+ 保留的最近消息（部分压缩或实验路径）
+ 文件/Plan/Skill/Agent 状态附件
+ SessionStart Hook 结果
```

程序还会确定性恢复：

- 最近读取的最多 5 个文件，每个最多 5K Token，总预算 50K。
- 当前 Plan 和 Plan Mode。
- 已调用 Skill：每个最多 5K，总预算 25K。
- 后台 Agent 状态。
- 延迟加载的工具定义和 MCP 指令。
- 下一轮重新加载 `CLAUDE.md` 和相关规则。

原始历史仍保存在会话 transcript 中，但不再发送给模型；SDK 内存中的压缩前消息会被释放。

### 6. 失败保护

如果摘要请求本身超过上下文限制：

- 按 API Round 从最旧部分开始丢弃。
- 有 Token 差值时按差值删除。
- 无法计算时，每次删除约 20% 的历史分组。
- 最多重试 3 次。

自动压缩连续失败 3 次后触发熔断，避免每轮反复调用模型。

因此，该仓库的核心压缩方法可以概括为：

> 先规则化删除高体积、低长期价值的工具结果，再用当前主模型生成任务状态摘要，最后通过程序化附件恢复不能只依赖摘要保存的关键上下文。


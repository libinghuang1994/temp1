# 参考仓库 Compact 实现分析

## 1. 总体结论

参考实现不是“达到阈值后调用一次摘要模型”，而是由四个层次组成：

1. 工具结果预算和轻量清理；
2. Token 阈值、输出预留和安全 Buffer；
3. 模型生成结构化会话摘要；
4. 压缩后对不可丢失状态进行确定性重注入。

标准路径仍需要模型调用。只有实验性的 Session Memory Compact 可以在触发压缩时直接使用此前维护的记忆文件，从而避免当场再次生成完整摘要。

## 2. 主循环顺序

`src/query.ts` 中与压缩相关的顺序为：

```text
applyToolResultBudget
→ History Snip（Feature Flag）
→ microcompactMessages
→ Context Collapse（Feature Flag）
→ autoCompactIfNeeded
→ buildPostCompactMessages
→ 正常模型请求
```

其中 History Snip 和 Context Collapse 在该社区仓库的默认构建中被禁用；Cached Microcompact 也依赖未公开的 Cache Editing Header。分析和移植时必须区分“源码存在”和“默认实际生效”。

## 3. API Context Management

`apiMicrocompact.ts` 构造 Anthropic `context_management` 请求字段：

- 默认触发输入：180,000 Token；
- 默认目标输入：40,000 Token；
- `clear_at_least`：140,000 Token；
- 主要面向 Shell、Glob、Grep、Read、WebFetch、WebSearch 等工具内容；
- 可通过 `API_MAX_INPUT_TOKENS`、`API_TARGET_INPUT_TOKENS` 调整。

这条路径属于 API 服务端上下文编辑。它可以在不生成自然语言摘要的情况下减少旧工具内容，但要求供应商支持对应 Beta；CoStrict 不能把它当成跨模型通用能力。

## 4. Auto Compact 阈值

`autoCompact.ts` 首先预留摘要输出空间：

```text
effectiveWindow = modelContextWindow
                - min(modelMaxOutputTokens, 20_000)
```

随后根据上下文窗口设置 Buffer：

| 有效窗口 | Buffer |
|---|---:|
| 小于 400K | 13K |
| 400K 至 800K | 30K |
| 800K 以上 | 50K |

```text
autoCompactThreshold = effectiveWindow - buffer
```

`CLAUDE_AUTOCOMPACT_PCT_OVERRIDE` 只可降低阈值：最终取百分比阈值与安全阈值中的较小值。这样可以避免用户把压缩点调得过晚，挤占摘要调用和下一轮输出空间。

实现还包括：

- `DISABLE_COMPACT`：关闭自动和手动压缩；
- `DISABLE_AUTO_COMPACT`：只关闭自动压缩；
- 连续失败 3 次后熔断；
- 对超长下一轮进行增长预估；
- 自动、手动和 API 413 后的 Reactive Compact 路径。

## 5. 摘要模型调用

`compact.ts` 的默认调用路径：

1. 执行 `PreCompact` Hook，并把 Hook 生成的附加要求合并到用户自定义 Compact Instructions。
2. 构造只允许文本输出的 Summary Prompt。
3. 默认创建单轮 Fork Agent，复用主对话的 Prompt Cache。
4. 使用当前 `mainLoopModel`，而非固定小模型。
5. 禁止压缩 Agent 调用工具。
6. 缓存共享失败时使用普通流式调用，Fallback 路径关闭 Thinking，摘要输出上限为 20K。

送给摘要模型之前：

- 只使用最近一个 `compact_boundary` 后的有效消息；
- 图片、文档被替换为文本标记；
- 压缩后会重注入的 Skill Discovery/Listing 附件被删除；
- 消息被规范化，避免孤立的 `tool_use` / `tool_result`。

## 6. Summary Prompt

`prompt.ts` 要求摘要覆盖：

1. 用户主要请求与意图；
2. 技术概念；
3. 文件、代码段和修改；
4. 错误及修复；
5. 问题解决过程；
6. 所有真实用户消息；
7. 未完成任务；
8. 当前工作；
9. 下一步。

模型输出 `<analysis>` 和 `<summary>`。程序在摘要进入新上下文前删除 `<analysis>` 草稿，只保留格式化后的 Summary，减少无效 Token。

## 7. 压缩后消息结构

```text
compact_boundary
+ synthetic user summary
+ messagesToKeep（仅部分/Session Memory 等路径）
+ deterministic attachments
+ SessionStart hook results
```

标准 Full Compact 将历史折叠为一条用户角色摘要。Boundary 写入 trigger、压缩前 Token 和逻辑父消息，用于恢复、持久化和 SDK 事件。

原始 transcript 仍保存在磁盘；模型调用只读取最新 Boundary 之后的活动视图。SDK 主循环会释放 Boundary 之前的内存消息，避免长会话持续占用内存。

## 8. 确定性重注入

Full Compact 成功后恢复：

- 最近读取文件：最多 5 个，每个最多 5K Token，总预算 50K；
- 当前 Plan 文件；
- Plan Mode 指令；
- 已调用 Skill：每个最多 5K，总预算 25K；
- 仍在运行或尚未取回结果的异步 Agent 状态；
- Deferred Tools、Agent Listing、MCP Instructions；
- SessionStart Hook 结果；
- 下一轮重新读取项目规则和记忆文件。

这部分是信息保留的关键：稳定规则与运行状态不完全依赖摘要模型是否记住。

## 9. 超长摘要请求与防 Thrashing

如果 Compact 请求本身触发 Prompt Too Long：

- 优先根据服务端返回的 Token Gap 删除最旧 API Round；
- 无法解析 Gap 时，每次删除约 20% 的最旧 Round；
- 保证至少剩余一个 Round；
- 最多重试 3 次；
- 连续 Auto Compact 失败 3 次后停止继续轰击 API。

按 API Round 删除比按单条消息删除更安全，因为不会轻易切断 assistant tool call 与 user tool result 的协议配对。

## 10. 实验路径

Session Memory Compact 在远端 Gate 或环境变量启用时：

- 使用此前异步维护的 Session Memory；
- 至少保留 10K Token 的最近原文；
- 至少保留 5 条含文本消息；
- 最近原文最多 40K Token；
- 调整切点以保护 Tool Pair 和 Thinking Block；
- 如果结果仍超过 Auto Compact 阈值，则回退到标准模型摘要。

这是一种“滚动记忆 + 最近原文”的方案，信息保留通常优于纯 Fresh Start，但系统复杂度和额外模型成本更高。


# CoStrict 差距与可移植性分析

## 1. CoStrict 当前能力

CoStrict 已经具备可继续演进的基础：

- 根据上下文占用百分比和安全窗口触发 Condense；
- 使用当前 Provider 生成 Summary；
- 将工具调用和结果转换为文本，兼容不同供应商；
- 为孤立 Tool Call 注入合成 Tool Result；
- 使用 `condenseParent` 非破坏性隐藏历史，支持 Rewind；
- Summary 作为用户消息形成 Fresh Start；
- 保存原始 `<command>` 工作流；
- 使用 Tree-sitter 注入文件结构；
- 自动压缩时补充 Environment Details；
- 大命令输出可落盘，并通过 `read_command_output` 按需读取；
- Condense 失败时使用 50% 滑动窗口回退。

这些能力不应在重构时被删除。特别是非破坏性历史标签和 Tree-sitter 文件折叠，是 CoStrict 相对参考实现有价值的设计。

## 2. 主要差距

| 能力 | 参考实现 | CoStrict 当前 | 建议 |
|---|---|---|---|
| 通用工具结果轻量清理 | API Context Management、Cached MC、预算化 | 主要覆盖命令输出入口 | 增加 Provider 无关 Observation Masking |
| 动态 Buffer | 按窗口 13K/30K/50K | 固定 10% + 输出预留 | 保留输出预留并改为动态 Buffer |
| 阈值上限保护 | 百分比只能提前 | Profile 可到 100%，靠 allowedTokens 兜底 | 统一取配置阈值与安全阈值较小值 |
| Compact Hook | PreCompact/PostCompact | 无统一 Hook | 增加内部事件接口，插件化后置 |
| 结构化摘要 Prompt | 九部分、真假用户消息防混淆 | Prompt 较详细但预算不明确 | 引入结构化 Schema 与硬预算 |
| Summary 草稿清理 | 删除 `<analysis>` | 直接保留模型文本 | 输出解析，只保留 Summary |
| 确定性重注入 | 文件、Skill、Plan、Agent、MCP、规则 | command、折叠文件、环境 | 建立 Reinjection Registry |
| Recent Tail | Session Memory/Partial 路径支持 | Fresh Start | 增加可配置 10K～20K Recent Tail |
| PTL 重试 | 按 API Round 剥离，最多 3 次 | 失败后滑窗 50% | 先对摘要请求做 Round 级重试 |
| 防重复压缩 | 连续失败熔断、重压缩指标 | Task 级窗口错误重试 | 增加会话级熔断和最小压缩间隔 |
| 真实压缩后 Token | 单独测量 Summary+附件 | 已测 system+summary+tools | 扩展为各阶段 Token Breakdown |

## 3. 可直接借鉴的部分

- 动态安全 Buffer 和阈值取最小值；
- 压缩前剥离图片、可重注入附件等噪声；
- 按 API Round 组织与裁剪；
- 明确的 Summary Prompt 结构；
- `<analysis>` 草稿剥离；
- Compact Boundary 元数据；
- 确定性 Reinjection Registry；
- 3 次失败熔断；
- 压缩前、清理后、摘要后和重注入后的 Token 指标。

## 4. 不应直接复制的部分

### 4.1 Anthropic 私有 Beta

Cached Microcompact 依赖未公开 Cache Editing Header。参考仓库对应常量为空，并明确说明无法在该 Fork 中真正启用。CoStrict 应实现客户端替代方案：把旧工具结果落盘，在发给模型的活动视图中替换为短标记。

### 4.2 Fork Agent Prompt Cache 共享

参考实现依赖其 API 参数、模型、工具和 Thinking 配置完全一致的 Fork 基础设施。CoStrict 初期应继续使用当前 `apiHandler.createMessage`；待指标证明 Compact 成本显著，再设计独立 Compact Model 或缓存共享。

### 4.3 GrowthBook 与内部遥测

所有远端实验 Gate 应映射为 CoStrict 自身配置、实验分桶和 Telemetry，不应保留 `tengu_*` 变量。

### 4.4 Context Collapse / History Snip

该社区仓库默认禁用了 Context Collapse 和 History Snip，前者注释中标为不完整。第一阶段不要移植；先完成稳定的 Tool Result Pruning、Summary 和 Reinjection。

### 4.5 完全覆盖 CoStrict 文件折叠

参考实现主要重新读取最近文件；CoStrict 已有 Tree-sitter Folded Context。建议组合使用：少量最相关文件保留受限原文，其余文件保留符号和签名，不要退回单一策略。

## 5. 推荐的目标行为

```text
活动历史
  ├─ 工具结果超预算 → 落盘 + 短标记
  ├─ 达到轻量清理阈值 → 清理旧 Observation，保留最近 N 个
  ├─ 达到安全 Compact 阈值 → 模型摘要
  └─ 摘要后：Summary + Recent Tail + Deterministic Context
```

目标不是机械复刻 Claude Code，而是在保持 CoStrict 多 Provider、Rewind 和代码折叠优势的前提下，引入参考实现的分层压缩和确定性恢复。


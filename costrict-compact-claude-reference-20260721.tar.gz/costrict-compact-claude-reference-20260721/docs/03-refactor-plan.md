# CoStrict Compact V2 改造方案

## 1. 设计目标

1. 在调用摘要模型前先移除高体积、低长期价值内容。
2. 压缩后关键规则、任务状态和代码上下文不依赖模型记忆。
3. 保留 CoStrict 的多 Provider、非破坏性 Rewind 和 Tree-sitter 折叠能力。
4. 压缩过程可观测、可灰度、可回退。
5. 以任务成功率为主指标，压缩比和成本为约束指标。

## 2. 建议目录

在 `src/core/context-management/` 下逐步形成以下结构：

```text
context-management/
├── index.ts                    # 兼容入口和编排
├── threshold.ts                # 有效窗口、动态 Buffer、预测触发
├── api-rounds.ts               # Tool Pair 安全分组与裁剪
├── tool-result-pruning.ts      # Observation Masking
├── compact.ts                  # Compact 主流程
├── compact-prompt.ts           # Prompt 与输出解析
├── reinjection.ts              # 确定性重注入注册表
├── compact-state.ts            # Boundary、失败次数、最小间隔
├── compact-metrics.ts          # Token Breakdown 与质量指标
└── __tests__/
```

现有 `src/core/condense/index.ts` 暂时保留为兼容层，内部转调 Compact V2，等稳定后再决定是否重命名。

## 3. Phase 0：先补观测

不改变行为，新增以下一次压缩事件字段：

```ts
type CompactMetrics = {
  trigger: "manual" | "auto" | "context_error"
  preCompactTokens: number
  afterToolPruningTokens: number
  compactInputTokens: number
  compactOutputTokens: number
  summaryTokens: number
  recentTailTokens: number
  reinjectedTokens: number
  truePostCompactTokens: number
  turnsSincePreviousCompact?: number
  consecutiveFailures: number
  durationMs: number
  provider: string
  model: string
}
```

验收：任意一次 Auto/Manual Condense 都能从日志还原 Token 去向，且不再用摘要 API 调用总 Token 代替压缩后活动上下文大小。

## 4. Phase 1：Provider 无关 Tool Result Pruning

### 4.1 触发策略

初始建议：

- 工具结果总量超过 30K Token 时评估；
- 保留最近 5 个完整 Tool Round；
- 每次至少释放 20K Token；
- 只清理成功落盘或可重新获取的结果；
- 当前正在使用、包含未解决错误、未完成补丁或用户明确要求保留的结果不得清理。

### 4.2 存储和活动视图

原始 Tool Result 继续保存在任务历史或 Artifact 文件。发给 API 时替换为：

```text
[Old tool result cleared]
tool=<name>
artifact=<id or path>
digest=<short semantic digest>
original_tokens=<n>
retrieve_with=<read_command_output/read_file/...>
```

不得删除 `tool_use_id` 或拆开 Tool Pair。对不支持附加字段的 Provider，在 API 转换层只发送文本标记；CoStrict 内部元数据保留在 `ApiMessage` 或独立索引中。

### 4.3 首批工具范围

1. `execute_command`：直接复用 OutputInterceptor Artifact。
2. 搜索、目录枚举、网页抓取：增加统一 Artifact Store。
3. `read_file`：允许重新读取时清理旧内容；文件已修改时必须保存读取时快照或摘要。
4. 写入/编辑结果：只清理冗长返回内容，保留参数、Diff 摘要和成功状态。

验收：同一任务上无需调用 Summary 即可降低至少 20% 活动 Token，且 Tool Pair 验证全部通过。

## 5. Phase 2：动态安全阈值

保留 CoStrict 对正常输出 Token 的保守预留，同时引入参考实现的动态 Buffer：

```text
reservedOutput = max(
  request.maxTokens,
  model.maxTokens,
  settings.maxTokens,
  providerDefaultMaxTokens
)

compactOutputReserve = min(providerCompactMaxTokens, 20_000)

effectiveWindow = contextWindow
                - max(reservedOutput, compactOutputReserve)

buffer = 13K / 30K / 50K（按窗口分段，可配置）
safetyThreshold = effectiveWindow - buffer
profileThreshold = contextWindow * configuredPercent
finalThreshold = min(profileThreshold, safetyThreshold)
```

相比直接照搬参考公式，这一版本继续保护 CoStrict 的多 Provider 大输出场景。

增加下一轮增长预测：使用最近 20 个 Turn 的 P95 增长量；样本不足时使用 15K Tool Result + 模型最大输出的保守估计。

验收：高输出模型不因过晚触发而出现 Context Window Error；用户百分比配置只能提前压缩，不能突破安全线。

## 6. Phase 3：结构化 Compact Agent

### 6.1 输入预处理

- 使用 Phase 1 清理后的活动视图；
- 图片和文档替换为标记；
- 跳过之后会确定性重注入的重复附件；
- 按 API Round 分组；
- 修复孤立 Tool Result；
- 仅总结最近 Summary/Boundary 之后的有效历史。

### 6.2 Prompt 输出结构

建议要求以下固定章节：

1. Primary Request and Intent
2. Constraints and Safety Instructions
3. Technical Decisions
4. Files and Code Changes
5. Errors and Corrections
6. User Feedback and Intent Changes
7. Pending Tasks
8. Current Work State
9. Next Action

要求模型用 `<analysis>` 做草稿、用 `<summary>` 给最终输出。程序必须删除 `<analysis>`；缺少 `<summary>` 时可接受纯文本，但记录格式降级指标。

### 6.3 模型选择

- V1：沿用当前 `apiHandler` 与当前模型，降低改造风险。
- V2：增加可配置 `compactModel`，默认与主模型相同。
- 仅当实验证明小模型的信息保留达标，才允许默认切换到低成本模型。

### 6.4 Prompt Too Long 重试

- 按 API Round 从最旧处剥离；
- 优先释放服务端提示的 Token Gap；
- 无 Gap 时每次删除 20% Round；
- 至少保留最后一个完整 Round；
- 最多 3 次；
- 每次写入 `droppedRounds`、`droppedTokens` 指标。

验收：摘要模型不调用工具；Summary 格式可解析；不会产生孤立 Tool Pair；超长摘要请求能有限次恢复。

## 7. Phase 4：Compact Boundary 和 Recent Tail

保留现有 `condenseParent/condenseId` 非破坏性模型，并为 Summary 增加：

```ts
type CompactMetadata = {
  trigger: "manual" | "auto" | "context_error"
  preCompactTokens: number
  afterPruningTokens: number
  compactedAt: number
  lastPreCompactMessageTs?: number
  recentTailStartTs?: number
  version: 2
}
```

目标活动上下文：

```text
Summary + Recent Tail + Reinjected Context
```

Recent Tail 建议默认 12K Token，并同时满足至少 4 条真实文本消息。切点必须向前调整到完整 Tool Round 边界。通过实验比较 0K、8K、12K、20K。

避免 Summary 与 Tail 大量重复：Prompt 明确“Recent Tail 将原文保留”，Summary 只写前置事实和承接所需状态。

## 8. Phase 5：Reinjection Registry

建立统一接口：

```ts
interface CompactContextProvider {
  id: string
  priority: number
  collect(ctx: CompactContext): Promise<CompactAttachment[]>
}

type CompactAttachment = {
  type: string
  content: string
  estimatedTokens: number
  source: string
  freshness: "snapshot" | "live"
}
```

首批 Provider：

- Project Rules / Memory；
- Active Command；
- Environment Details；
- Plan / Todo；
- Invoked Skills；
- Async Task 状态；
- MCP Instructions / 动态工具信息；
- Recent File Context。

文件策略采用混合方案：

- 最近且与当前任务直接相关的 2 个文件：每个最多 5K Token 原文；
- 其他近期文件：继续使用 Tree-sitter 符号折叠；
- 文件总预算初始 40K；
- 总重注入预算初始 60K；
- 超预算时按 priority、recency、task relevance 排序，而不是简单按输入顺序截断。

验收：项目规则、Active Workflow、Plan 和已调用 Skill 在压缩后第一轮均可检测到；重注入绝不突破预算。

## 9. Phase 6：失败保护与灰度

增加会话级状态：

- 连续 Compact 失败达到 3 次后熔断；
- Compact 后至少经过 2 个 Turn 才允许再次自动压缩，除非 API 返回 Context Error；
- 如果 `truePostCompactTokens >= finalThreshold`，立即标记质量失败，不进入正常循环；
- 首次失败回退到更激进的工具清理；
- 第二次失败缩小 Recent Tail 和 Reinjection；
- 第三次才使用现有 50% Sliding Window；
- Sliding Window 应按 API Round 和 Token 价值裁剪，不再只按消息数量。

建议 Feature Flags：

```text
contextCompactV2
compactToolResultPruning
compactStructuredPrompt
compactRecentTailTokens
compactReinjectionRegistry
compactRoundRetry
compactCircuitBreaker
```

灰度顺序：内部开发者 → 5% → 20% → 50% → 默认开启；任何阶段 Context Error、任务失败率或重复压缩率显著上升即回退。

## 10. 推荐实施顺序

| 优先级 | 工作 | 预计风险 |
|---|---|---|
| P0 | Token Breakdown、失败计数、真实压缩后大小 | 低 |
| P0 | API Round 分组和协议不变量测试 | 低 |
| P1 | execute_command Tool Result Pruning | 中 |
| P1 | 动态阈值和安全上限 | 中 |
| P1 | Structured Prompt 与 `<analysis>` 剥离 | 中 |
| P1 | PTL Round Retry 和熔断 | 中 |
| P2 | Reinjection Registry | 中高 |
| P2 | Recent Tail | 中高 |
| P3 | 通用 Artifact Store、独立 Compact Model | 高 |

第一批上线不应包含私有 API Context Management、Cache Editing 或 Session Memory 后台抽取，以控制变量和工程复杂度。


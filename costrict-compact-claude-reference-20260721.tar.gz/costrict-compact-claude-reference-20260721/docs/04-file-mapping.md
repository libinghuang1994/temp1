# 上游代码与 CoStrict 文件映射

## 1. 上游核心文件

| 上游文件 | 作用 | CoStrict 目标 |
|---|---|---|
| `services/compact/autoCompact.ts` | 有效窗口、Buffer、阈值、熔断 | `core/context-management/threshold.ts`、`compact-state.ts` |
| `services/compact/compact.ts` | Summary 调用、重试、Boundary、附件 | `core/context-management/compact.ts` |
| `services/compact/prompt.ts` | 结构化 Prompt、Summary 解析 | `core/context-management/compact-prompt.ts` |
| `services/compact/microCompact.ts` | 旧工具结果清理编排 | `core/context-management/tool-result-pruning.ts` |
| `services/compact/apiMicrocompact.ts` | Provider API Context Management | 仅作能力探测；跨 Provider 使用本地替代 |
| `services/compact/grouping.ts` | API Round 分组 | `core/context-management/api-rounds.ts` |
| `services/compact/reactiveCompact.ts` | 413 后紧急压缩 | `Task.ts` Context Error 路径 |
| `services/compact/postCompactCleanup.ts` | 清理失效缓存和状态 | `compact-state.ts` / Task 生命周期 |
| `services/compact/sessionMemoryCompact.ts` | 记忆 + Recent Tail 实验 | 后续实验，不进入首批改造 |
| `query.ts` | 主循环接入顺序 | `Task.recursivelyMakeClineRequests` 附近 |

## 2. CoStrict 当前文件处理建议

| CoStrict 文件 | 建议变更 |
|---|---|
| `src/core/context-management/index.ts` | 保留公开接口；把阈值、轻量清理、Summary、回退拆为模块 |
| `src/core/condense/index.ts` | 过渡期保留；复用现有 Provider 转换和非破坏性标签，逐步变成兼容 Wrapper |
| `src/core/condense/foldedFileContext.ts` | 保留并接入 Reinjection Registry，增加优先级和 Token 预算 |
| `src/shared/support-prompt.ts` | 将 Compact V2 Prompt 独立，避免默认 Prompt 与其他支持 Prompt 耦合 |
| `src/integrations/terminal/OutputInterceptor.ts` | 作为 Tool Result Artifact Store 的第一个 Backend |
| `src/core/tools/ReadCommandOutputTool.ts` | 继续作为命令结果恢复入口，并增加 Compact Marker 兼容 |
| `src/core/message-manager/index.ts` | 增加 Compact V2 Boundary/Recent Tail 的 Rewind 清理逻辑 |
| `src/core/task/Task.ts` | 调整接入顺序、熔断、Context Error 三级回退和 Telemetry |
| `packages/types/src/context-management.ts` | 增加 Compact V2 配置、元数据和指标类型 |
| `packages/types/src/global-settings.ts` | 增加 Feature Flag/配置 Schema，并保持旧配置兼容 |

## 3. 建议新增类型

```ts
type CompactTrigger = "manual" | "auto" | "context_error"

type ToolResultReference = {
  toolUseId: string
  toolName: string
  artifactId?: string
  digest: string
  originalTokens: number
  createdAt: number
}

type CompactBoundary = {
  compactId: string
  trigger: CompactTrigger
  preCompactTokens: number
  afterPruningTokens: number
  truePostCompactTokens: number
  recentTailStartTs?: number
  version: 2
}
```

## 4. 建议新增测试文件

```text
src/core/context-management/__tests__/api-rounds.spec.ts
src/core/context-management/__tests__/tool-result-pruning.spec.ts
src/core/context-management/__tests__/compact-prompt.spec.ts
src/core/context-management/__tests__/reinjection.spec.ts
src/core/context-management/__tests__/compact-v2.spec.ts
src/core/context-management/__tests__/compact-retry.spec.ts
src/core/context-management/__tests__/compact-rewind.spec.ts
```

## 5. 首批最小变更集

如果需要将范围控制在一个迭代，建议只修改：

1. `context-management/index.ts`：动态阈值、失败熔断；
2. 新增 `api-rounds.ts`；
3. 新增 `tool-result-pruning.ts`，首期只覆盖命令输出；
4. `condense/index.ts`：结构化 Prompt、分析草稿剥离、PTL Round Retry；
5. `Task.ts`：记录阶段 Token 与连续失败；
6. 对应单元测试。

Reinjection Registry 和 Recent Tail 放到第二个迭代，可显著降低首批回归风险。


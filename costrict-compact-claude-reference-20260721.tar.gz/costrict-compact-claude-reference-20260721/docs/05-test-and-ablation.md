# 测试、消融实验与验收标准

## 1. 不变量测试

每个 Provider 都必须满足：

- 第一条 API 消息角色合法；
- 每个 `tool_result` 都有对应 `tool_use`；
- 不从同一 Tool Round 中间切开；
- Summary 存在时旧消息不会进入活动 API 历史；
- 删除/回退 Summary 后，`condenseParent` 消息可恢复；
- Recent Tail 不包含重复 Boundary；
- Reinjection 总量不超过预算；
- 压缩失败不会覆盖原始消息；
- 连续失败达到上限后停止自动重试；
- Manual Compact 仍可在 Auto Compact 关闭时执行。

## 2. 单元测试重点

### Tool Result Pruning

- 超过阈值时保留最近 N 个结果；
- 未超过阈值时严格 No-op；
- Artifact 写入失败时不清理原文；
- Read 文件已修改时保留快照引用；
- 错误输出和当前工作结果受到保护；
- 重复执行具有幂等性。

### API Round

- Assistant Thinking、Tool Use、User Tool Result 被视为一个不可分割 Round；
- 并行 Tool Call 的多个结果不会被拆散；
- 孤立结果被修复或剔除；
- PTL 重试每次都取得 Token 减少。

### Summary 与重注入

- `<analysis>` 不进入新上下文；
- 九个 Summary 字段可解析；
- Active Command、规则、Plan、Skill 在压缩后仍存在；
- 文件原文与 Folded Context 不重复注入；
- 超预算时低优先级附件先被丢弃。

## 3. 集成任务集

至少包含以下场景：

1. 长代码导航：连续读取和搜索 30～50 个文件。
2. 调试：多轮命令输出、错误、修复和回归测试。
3. 跨文件重构：10 个以上文件，包含 Plan 和未完成 Todo。
4. 用户中途改变要求：验证意图变化和否定约束是否保留。
5. 多 Provider：Anthropic、OpenAI Compatible、Bedrock/LiteLLM。
6. Rewind：压缩后回退到压缩前检查历史恢复。
7. Context Error：主动制造摘要请求过长和主请求 413。
8. 连续长会话：至少发生三次 Compact，检查是否 Thrashing。

## 4. 核心指标

```text
轻量清理压缩率 = 1 - afterPruningTokens / preCompactTokens
总压缩率       = 1 - truePostCompactTokens / preCompactTokens
摘要膨胀率     = summaryTokens / compactInputTokens
重注入占比     = reinjectedTokens / truePostCompactTokens
Compact 成本   = compact API input + output cost
再次压缩间隔   = turnsUntilNextCompact
```

质量指标：

- 任务成功率；
- 关键事实召回率；
- 用户约束召回率；
- 文件/符号状态准确率；
- 未完成任务召回率；
- 压缩后重复 Read/Grep 次数；
- Context Window Error 率；
- Compact 后三轮内错误操作率。

## 5. 消融实验

| ID | 实验组 | 对照组 | 主要问题 |
|---|---|---|---|
| A1 | Tool Result Pruning + Summary | 仅 Summary | 轻量层能否降低成本并提升压缩比 |
| A2 | 动态 Buffer | 固定 10% Buffer | 是否降低 Context Error 且不过早压缩 |
| A3 | Structured Prompt | 当前 Condense Prompt | 是否提升关键事实和约束召回 |
| A4 | Summary + 12K Tail | 仅 Summary | Recent Tail 是否提升继续任务成功率 |
| A5 | 混合文件恢复 | 仅 Tree-sitter Fold | 少量原文是否降低重复读取和代码错误 |
| A6 | Reinjection Registry | 全靠 Summary | 确定性恢复是否减少约束丢失 |
| A7 | Round Retry | 直接 50% Sliding Window | PTL 恢复是否更少丢失信息 |
| A8 | 当前主模型摘要 | 小模型摘要 | Compact 成本与信息质量的 Pareto 边界 |
| A9 | Recent Tail 0/8K/12K/20K | 多臂 | 找到信息保留与 Token 成本平衡点 |
| A10 | 文件预算 20K/40K/60K | 多臂 | 找到文件恢复最佳预算 |

## 6. 推荐验收门槛

第一阶段相对当前 CoStrict：

- 任务成功率不得下降超过 1 个百分点；
- Context Window Error 率下降至少 30%；
- Compact 前输入 Token 中位数减少至少 20%；
- Compact 后关键事实召回率不低于 95%；
- 用户安全和禁止性约束召回率达到 100%；
- 三轮内重复 Compact 率下降至少 50%；
- Tool Pair 协议错误为 0；
- Rewind 测试全部通过。

第二阶段目标：在任务成功率不下降的条件下，使 Compact 调用成本下降 20%～35%，压缩后重复文件读取次数下降 15%以上。

## 7. 推荐实验顺序

1. A1：先确认 Tool Result Pruning 的独立价值。
2. A3：确认结构化 Prompt 的信息质量。
3. A6：验证确定性重注入。
4. A4/A9：选择 Recent Tail 大小。
5. A5/A10：优化文件恢复预算。
6. A2/A7：验证稳定性和异常恢复。
7. A8：最后评估独立 Compact Model，避免多变量同时变化。


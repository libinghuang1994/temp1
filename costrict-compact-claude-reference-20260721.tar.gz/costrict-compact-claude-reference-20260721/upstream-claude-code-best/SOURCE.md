# 上游源码说明

- Repository: <https://github.com/claude-code-best/claude-code>
- Commit: `34b3dc99bf40c57c0b78f3b5b1d70471ebc2d06d`
- Commit date: `2026-07-21T09:27:47+08:00`
- Commit subject: `chore: v2.8.4`
- 获取方式：`git clone --depth 1`

本目录中的文件保持该 commit 的原始内容，仅按目录重新收集，便于研究 Compact 调用链。

上游 README 声明项目仅供学习研究，Claude Code 的相关权利归 Anthropic 所有。本资料包中的上游快照亦仅用于本次架构研究和内部改造参考；如需分发或用于生产交付，请先完成许可证与权利审查。

## 收录范围

- `src/services/compact/`：压缩核心、提示词、阈值、Microcompact、Session Memory 路径及测试。
- `src/services/SessionMemory/`：实验性会话记忆生成与裁剪。
- `src/query.ts`：主循环中工具结果预算、Microcompact、Auto Compact 和替换消息的接入点。
- `src/services/claude-api-integration.ts`：原 `src/services/api/claude.ts`，包括 API Context Management 接入。
- `src/utils/` 与 `src/constants/`：Token、上下文窗口、Boundary、Beta Header 和 SessionStart 支撑代码。


# DiCode Agent 生产缺陷测评报告

日期：2026-08-02  
状态：阶段性正式报告  
测评目标：通过真实 Agent 长任务发现并修复生产级瑕疵，而不是追求 SWE-bench 跑分

## 1. 执行摘要

本轮使用真实 `deepseek-v4-flash`、DiCode CLI/Extension IPC、受限 Docker 案例环境和官方 SWE-bench harness，覆盖 Python、C、C++ 六个代表任务。

测评确认并闭环了两项 DiCode 产品缺陷：

1. 正常完成任务时，`attempt_completion` 的工具结束事件和 `task_finished` 可能缺失，导致 UI/审计看到未闭合生命周期；
2. 普通源码编辑会错误进入 coworkflow checkpoint metadata 更新路径，在没有 `checkpoint_saved` 消息时读取 `undefined.text`，并静默禁用 checkpoints。

测评还确认并修复了一项报告可观测性缺口：

- `execute_command` 子进程非零退出时，AgentAction 只表示工具协议成功，旧报告中的 `failedTools=0` 容易被误读为所有命令都成功。报告器现从既有、已保存的 CLI stream 中去内容化统计命令退出码，不改变冻结接口。

最终选取的六个代表运行结果如下：

| 案例                              | 语言     | Agent 终态   | 模型请求 | 工具调用 |    补丁 | 官方结果        | 生命周期 hard gate |
| --------------------------------- | -------- | ------------ | -------: | -------: | ------: | --------------- | ------------------ |
| `sympy__sympy-20590` v9           | Python   | 自然完成     |       26 |       34 |   469 B | `resolved=true` | 通过               |
| `django__django-10914` v2         | Python   | 自然完成     |       22 |       35 | 5,292 B | `resolved=true` | 通过               |
| `matplotlib__matplotlib-23964` v4 | Python   | 自然完成     |       31 |       37 | 1,465 B | `resolved=true` | 通过               |
| `redis__redis-13115` v2           | C        | 自然完成     |       26 |       33 | 1,966 B | `resolved=true` | 通过               |
| `fmtlib__fmt-3158` v2             | C++      | 请求上限终止 |       32 |       38 | 1,746 B | `resolved=true` | 未通过             |
| `nlohmann__json-4237` v1          | C++      | 请求上限终止 |       32 |       46 | 2,720 B | `resolved=true` | 未通过             |
| **合计**                          | 3 种语言 | 4 次自然完成 |  **169** |  **223** |       — | 6 个补丁通过    | **4/6**            |

这组结果不是随机抽样的排行榜成绩：SymPy、Django、Redis 和 fmt 都有重复运行，表格选择的是用于验证最终行为或保存缺陷证据的代表运行。因此不能把 `6/6` 宣传为 DiCode 的一般化 SWE-bench 通过率。

更重要的生产结论是：正确补丁和可靠运行是两个独立维度。fmt 和 nlohmann/json 的补丁通过官方测试，但 Agent 没有自然完成，生命周期 hard gate 正确地拒绝把它们算成“完整有效的成功运行”。

## 2. 测评设计

### 2.1 执行链路

```text
固定 SWE-bench 案例
    -> published base_commit 工作区
    -> 官方案例镜像派生的 DiCode Agent 容器
    -> DiCode CLI + Extension IPC + 真实 Provider
    -> 去内容化 AgentAction 生命周期证据
    -> model.patch
    -> predictions.jsonl SHA 绑定
    -> 隔离的官方 SWE-bench harness
    -> correctness + runtime evidence 双报告
```

### 2.2 判定信号彼此独立

- `resolved=true`：只由官方 SWE-bench fail-to-pass/pass-to-pass 测试判定；
- `hardGatePassed=true`：事件连续，model/tool/task 全部配对关闭，task finish 是最后事件；
- `agentStatus=completed`：Agent 进程自然完成；
- `model-request-limit`：评测安全边界在下一次请求启动时终止；
- `failedTools`：AgentAction 的工具协议失败数，不等于 shell 命令非零退出数；
- `nonZeroCommandExits`：报告器从已有 CLI stream 观察到的明确非零命令退出数。

官方正确性不能覆盖运行时证据失败，运行时 hard gate 也不能替代补丁正确性。

### 2.3 无 gold 泄漏

- 案例选择只使用公开 metadata 和问题描述；
- Agent 只接收 issue 描述及 published `base_commit` 工作区；
- 运行前不读取 gold patch 或 test patch；
- 官方 harness 只在 Agent 结束、补丁固定后运行；
- predictions SHA-256 与独立 harness manifest 绑定，防止判定后修改补丁或混入旧结果。

## 3. Python 案例

### 3.1 SymPy：completion 生命周期缺陷闭环

`sympy__sympy-20590` 是建立真实 Agent 管线和生命周期门禁的主案例。

代表性演进：

| 运行 | Agent/补丁结果                     | 生命周期结果                                             |
| ---- | ---------------------------------- | -------------------------------------------------------- |
| v4   | 469 B，官方通过；旧请求预算终止    | task/model 未闭合                                        |
| v6   | 13 请求后自然退出，469 B，官方通过 | 缺 `attempt_completion tool_finished` 和 `task_finished` |
| v7   | 27 请求，964 B，官方通过           | tool/task 仍未完全闭合                                   |
| v8   | 26 请求，469 B，官方通过           | tools 已闭合，task 未闭合                                |
| v9   | 26 请求，469 B，官方通过           | model/tool/task 全部闭合，hard gate 通过                 |

v6 的关键证据是：CLI stdout 已发送成功的 `control.done`/`task_completed`，但 AgentAction 最后一条仍是 `attempt_completion` 的 `tool_started`。因此不是模型没有完成，也不是评测器误判，而是产品内部完成路径的事件顺序/收尾缺陷。

修复保持现有事件形状不变，在 `AttemptCompletionTool`、`Task` 和 `AgentActionRecorder` 的所有权边界内补齐完成顺序，并通过连续真实复测将缺口逐步收敛。v9 最终证明：

- `agentExitCode=0`；
- `agentStatus=completed`；
- `modelsClosed=true`；
- `toolsClosed=true`；
- `taskClosed=true`；
- `lifecycleClosed=true`；
- `hardGatePassed=true`；
- 官方 `resolved=true`。

该修复提升的是生产生命周期可靠性和 UI/审计一致性，不是通过修改 Agent 推理策略提高分数。

### 3.2 Django：自然完成和完整证据

`django__django-10914` v1 在 32 次请求后被安全边界终止，但其 3,784 B 补丁已经官方通过。v2 自然完成：

- 22 次模型请求；
- 35 次工具调用；
- 5,292 B 补丁；
- 官方 `resolved=true`；
- model/tool/task 全部闭合；
- runtime hard gate 通过。

这说明请求上限终止并不等价于错误补丁，也说明同一问题上模型运行存在非确定性。报告必须同时展示 correctness 和 lifecycle，不能只展示一个“通过”。

### 3.3 Matplotlib：适配器假超时修复后闭环

Matplotlib 早期运行曾在约 31 秒时表现为 Agent timeout。根因不是模型或 Agent 卡死，而是宿主 Unix socket 路径长达 119 字节，超过 Linux AF_UNIX 路径限制。

修复后 IPC socket 使用系统临时目录中的短路径，并在结束后清理。`matplotlib__matplotlib-23964` v4 随后实现：

- 31 次模型请求；
- 37 次工具调用；
- 1,465 B 补丁；
- 自然退出 0；
- 官方 `resolved=true`；
- lifecycle hard gate 通过。

该问题归属于评测适配器，不属于 Agent 推理缺陷。若不先修复，它会污染对 Agent 超时率和稳定性的判断。

## 4. C 语言案例：Redis

### 4.1 产品缺陷发现

`redis__redis-13115` v1 的补丁官方通过，但每次普通源码编辑后，stderr 多次出现：

```text
[Task#updateCospecMetadataForCheckpoint] caught unexpected error, disabling checkpoints
TypeError: Cannot read properties of undefined (reading 'text')
```

实际独立异常为 3 次。根因位于 `src/core/checkpoints/index.ts`：实现尚未确认编辑目标是否为 coworkflow 文档，就读取第一条 `checkpoint_saved` 消息的 `.text`。普通源码编辑没有该消息，因此得到 `undefined.text`。

### 4.2 产品修复

修复后的顺序是：

1. 没有编辑路径时返回；
2. 非 coworkflow 文档直接返回；
3. 安全查找最新 `checkpoint_saved`；
4. 尚无 checkpoint 时不更新 metadata，也不抛异常。

没有修改 Webview、Extension、Provider、IPC、消息、存储或网络冻结合同。

### 4.3 前后真实对照

| 项目                         |       Redis v1（修复前） |  Redis v2（修复后） |
| ---------------------------- | -----------------------: | ------------------: |
| checkpoint metadata 独立异常 |                        3 |                   0 |
| Agent 终态                   | 第 33 次请求触发安全终止 | 26 次请求后自然完成 |
| 工具调用                     |                       36 |                  33 |
| 补丁大小                     |                    779 B |             1,966 B |
| 官方结果                     |          `resolved=true` |     `resolved=true` |
| lifecycle hard gate          |                   未通过 |                通过 |

修复证据由四层组成：确定代码根因、聚焦回归测试、类型检查、同一真实案例修复前后重跑。Redis v1/v2 都通过官方测试，反而证明该修复不是为了“刷过案例”，而是为了消除隐藏的 checkpoint 可靠性故障。

## 5. C++ 案例

### 5.1 fmt：正确补丁但没有生命周期闭环

`fmtlib__fmt-3158` 两次运行都使用 32 次请求和 30 分钟边界：

| 项目      | fmt v1 |          fmt v2 |
| --------- | -----: | --------------: |
| 模型请求  |     32 |              32 |
| 工具调用  |     39 |              38 |
| 补丁      |    0 B |         1,746 B |
| 官方结果  | 未判定 | `resolved=true` |
| hard gate | 未通过 |          未通过 |

v1 将预算用于搜索、阅读和复现，没有修改工作区。v2 直到第 31、32 轮才落地两次修改，随后发起第 33 次请求而被终止。补丁正确，但运行证据无效。

这没有证明 Agent 进入机械死循环：后半程操作仍有语义进展。更准确的风险是复杂 C++ 任务中探索过长、编辑过晚，没有为验证和 `attempt_completion` 预留请求预算。

### 5.2 nlohmann/json：过度验证和完成动作缺失

`nlohmann__json-4237` v1：

- 运行 313.378 秒；
- 32 次模型请求；
- 46 次工具调用；
- 2,720 B 补丁；
- 官方 `resolved=true`；
- lifecycle hard gate 未通过。

核心修复在第 16 次请求后已经落地，Agent 又执行了多个不同测试目标，并在第 32 次请求后继续请求，没有调用 `attempt_completion`。这些不是同一命令的机械重复，因此归因为验证策略过度和完成预算管理风险，而不是工具死锁。

Agent 自己执行的目标测试、完整 `unit-udt`、单头文件测试、`unit-udt_macro`、`unit-conversions`、`unit-regression2` 和 `unit-serialization` 均通过；官方 harness 也确认补丁正确。

## 6. action telemetry 可观测性

### 6.1 缺口

fmt 和 nlohmann/json 都出现过编译、链接、ripgrep 或 shell 非零退出，但旧报告仍显示：

```text
failedTools=0
```

实现语义是：只要 `execute_command` 成功启动子进程并把结果返回模型，工具协议就记录为 success。该语义本身可以成立，但报告字段 `Failed tools` 容易被理解为“命令全部成功”。

### 6.2 兼容修复

修复没有修改 `AgentActionEvent`、CLI stream、IPC、Provider 或持久化合同。评测报告器读取已经保存的 `agent.stdout.log` 中既有 `tool_result`：

- 只聚合完成命令 ID 和 exit code；
- 不保存或展示命令文本、输出、路径和错误正文；
- 分开展示 `Protocol failed/blocked`；
- 新增 `Command nonzero/observed/unknown`；
- 旧证据没有 stdout 时安全返回 0/0/0。

对 nlohmann 原始证据重放后的结果：

```text
Protocol failed/blocked: 0/0
Command nonzero/observed/unknown: 1/16/0
```

该统计不会猜测被 shell pipeline 自身改写成 0 的内部失败。Agent 构造未启用 `pipefail` 的 pipeline 属于命令构造/模型行为，必须与 telemetry 分开。

## 7. checkpoint Git 仓库问题的相邻审计

Agent 测评期间，用户反馈进一步触发 checkpoint Git 路径审计。最终保留两项产品改进：

- P1：保留 checkpoint 禁用的真实原因，嵌套仓库向用户显示准确原因，不再错误提示“安装 Git”；
- P2：识别 `.git` 为文件的嵌套 worktree，并在创建不完整 shadow checkpoint 前安全拒绝。

两项候选被审计后回退：

- P3：改变 `vendor/`、`deps/` 清理语义可能在恢复旧 checkpoint 时删除受维护内容，风险不可接受；
- P4：运行时采样不能保证严格 250 ms 上界，且重复读取 ignore 配置，收益不足以覆盖复杂度。

P3/P4 的回退是生产审计价值的一部分：测评目标不是保留更多改动，而是避免为了修一个风险引入更危险的新行为。

## 8. 测评基础设施修复

为避免基础设施错误冒充 Agent 缺陷，本阶段修复了：

1. Unix socket 路径过长导致的假 timeout；
2. materializer 忽略 `--case`、实际物化非选定案例；
3. 模型请求额度 off-by-one，旧逻辑在第 N 次请求启动时提前终止；
4. 通用 Debian 镜像缺少案例 testbed 环境；改为从精确官方案例镜像派生 Agent 镜像；
5. Python-only `/opt/miniconda3/envs/testbed/bin/python` 假设阻止 C/C++ 案例；
6. 容器内旧 checkout 可能覆盖挂载工作区；设置 workspace-first `PYTHONPATH`；
7. 官方 harness 复用目录可能混入旧结果；改为每次隔离目录并绑定 predictions SHA；
8. runtime hard gate 原本只是报告字段；现生成报告后若生命周期不完整则命令非零退出；
9. 安全终止被重复归因成额外 critical lifecycle defect；诊断归因改为保守且不重复惩罚；
10. 报告无法区分工具协议和子进程退出状态；新增去内容化 command exit metrics。

这些改动属于测评适配器，不改变 Agent 的模型、系统提示词、工具选择策略或推理算法。

## 9. 上下文压缩观测

六个代表运行共记录 165 次自动压缩检查，实际压缩为 0 次：

| 案例             | 压缩检查 | 实际压缩 |
| ---------------- | -------: | -------: |
| SymPy v9         |       25 |        0 |
| Django v2        |       21 |        0 |
| Matplotlib v4    |       30 |        0 |
| Redis v2         |       25 |        0 |
| fmt v2           |       32 |        0 |
| nlohmann/json v1 |       32 |        0 |
| **合计**         |  **165** |    **0** |

这不是自动压缩失效的证据。DeepSeek 当前模型元数据声明 1,000,000 token 上下文，运行中的阈值没有达到；nlohmann/json 最后一次检查的 `beforeTokens` 约 153,250，策略仍为 `compactionTrigger=none`。

因此 Agent 任务只能证明压缩检查链路持续运行，不能证明真实自动压缩后的 Agent 行为。上下文压缩质量由独立 ContextBench/V2-vs-Legacy 报告覆盖，不能把两套证据混在一起。

## 10. 验证结果

已经完成的主要验证包括：

- SymPy v9 真实运行：官方通过，Agent 自然完成，生命周期 hard gate 通过；
- Django v2、Matplotlib v4、Redis v2：官方通过且生命周期闭环；
- fmt v2、nlohmann/json v1：官方通过但 hard gate 明确失败；
- checkpoint metadata 单文件回归：27/27 通过；
- checkpoint P3/P4 回退后相关测试：87/87 通过；
- telemetry 报告聚焦测试：35/35 通过；
- `@roo-code/evals` 类型检查和 ESLint 通过；
- source 类型检查通过；
- 相关 Prettier、`git diff --check` 通过；
- 冻结接口 protected-path diff 为空；
- 最终 VSIX 发布审计中，覆盖 AgentAction、AttemptCompletion、Task、checkpoint、MCP、provider 和 packager 的选定测试集退出 0。

没有运行一个预先注册、不可挑选结果的全量 SWE-bench suite，因此不报告总体通过率或置信区间。

## 11. 当前风险

### 11.1 Agent 策略风险

- 复杂 C++ 任务可能探索和验证过长，编辑过晚；
- fmt/nlohmann 已证明正确补丁仍可能没有 `attempt_completion`；
- 请求上限只是安全边界，不是通用死循环检测；
- shell pipeline 未启用 `pipefail` 时可掩盖内部失败。

### 11.2 产品风险

- checkpoint metadata 已修复的具体异常不代表所有附属副作用失败都能被 AgentAction 感知；
- P1/P2 checkpoint 修复虽有测试，但复杂真实 nested worktree 组合仍应持续观察；
- AgentAction 事件保持去内容化后，详细失败归因仍需与 CLI stream/日志做受控关联。

### 11.3 测评风险

- 真实运行使用同一模型，不能代表所有 Provider；
- 重复运行包含模型非确定性；
- 代表运行是修复闭环样本，不是随机总体样本；
- 大型证据位于机器本地 E 盘，交付时需要继续校验 archive SHA；
- 本机没有 DiCode 固定远端后端，不能替代用户环境的最终 VSIX 联调。

## 12. 生产判断

当前证据支持以下判断：

1. DiCode Agent 主链路已经能够在 Python、C、C++ 真实仓库中生成官方正确补丁；
2. completion 生命周期和 checkpoint metadata 两个真实产品缺陷已经通过“真实复现 -> 最小根因 -> 聚焦测试 -> 修复后真实重跑”闭环；
3. runtime evidence hard gate 能阻止“补丁正确但运行未闭环”被误报为完整成功；
4. command exit telemetry 已能兼容地区分协议成功与子进程失败；
5. C++ 长任务仍暴露完成预算管理风险，因此不能宣称 Agent 已在所有复杂任务上达到完全自主、稳定终止。

推荐状态：**可以作为受控生产候选交付，但应保留 runtime hard gate、请求/时间安全边界、checkpoint 降级保护和详细诊断；继续把 C++ 任务的编辑时机与正常完成率作为下一轮重点，而不是只扩大案例数量。**

## 13. 后续建议

1. 增加一个不依赖固定 32 次上限的“剩余预算提醒/完成阶段”实验，但先放在 evaluator 或策略层，不改变冻结合同；
2. 选取新的独立 C++ 长任务，观察“核心修复完成后是否过度验证”能否复现；
3. 为 shell pipeline 的 exit-code 语义建立报告提示，避免把 pipeline 最终 0 当作内部每步都成功；
4. 增加 checkpoint 附属副作用失败的最小复现，验证 telemetry 能否表达“主工具成功、附属动作失败”；
5. 在可连接真实 DiCode 后端的用户环境进行 VSIX 最小联调；
6. 保留所有原始失败证据，不因新版本通过而删除 v1/v6 等缺陷样本。

## 14. 证据索引

主证据目录：

`E:\DiCodeAgentEvals`

关键归档：

| 证据                       | SHA-256                                                            |
| -------------------------- | ------------------------------------------------------------------ |
| Redis v1                   | `8cd87027f7bb1d0726d7a71ec9bea7e862c5019d918d3dbba1adc6712254e727` |
| Redis v2                   | `c80db00eac86d96095e4d633e8331068d67d14a6827258e9f7e8b854954324e8` |
| fmt v1                     | `acf5713eef48469a7d60daf3f39bff4e616761215ee8bf2124bb895c5c1c0da7` |
| fmt v2                     | `52c9b5e51dcc859c3c05ce81a4bdf1ccb249299b0d83bc5644eff6641bfe5b36` |
| nlohmann/json v1           | `3cab110385e4c3527d995d9e5a94302d664ed117a8c181576856a47b097a46c2` |
| nlohmann telemetry postfix | `eff51170bff649631f885e92352617939dac266b66b036871a1db0dafa2add2e` |

仓库内参考：

- `改进的agent部分.md`
- `用户反馈的git仓库问题.md`
- `docs/agent-evals/SWEBENCH_PIPELINE_CURRENT_STATE_2026-07-31.md`
- `evals/agent-loop/swebench-smoke/`
- `evals/agent-loop/swebench-multilingual-smoke/`
- `evals/agent-loop/swebench-multilingual-cpp-followup/`

## 15. 最终结论

本轮 Agent 测评的最大价值不是得到若干通过案例，而是用真实任务发现了“正确补丁之外”的生产问题：完成事件可能丢失、checkpoint 附属逻辑会静默失败、命令非零退出会被报告语义遮蔽、复杂 C++ 任务可能在补丁正确后仍无法正常结束。

其中 completion 生命周期、checkpoint metadata 和 command-exit 报告已闭环；C++ 完成策略仍是明确的剩余风险。DiCode Agent 已具备受控生产候选所需的主链路能力和故障门禁，但尚不应被描述为在所有长任务上都能稳定自主完成。

# dicode-agent-kpi-swebench-lite-50-v1

- Dataset: `princeton-nlp/SWE-bench_Lite`
- Suite SHA-256: `76ca17ce3f7524f58d84e0b4cba501b4d548e4271a49b81513109f69b280774e`
- Runner SHA-256: `055716aee1a21510cba8ae03e417b9eb9569074e4d4c6910e8512e4605127387`
- Repository: `5f2010f712af99b944a89dd2de2fd83062523c4d` (dirty)
- Harness: `swebench 4.1.0`, `datasets 5.0.1`
- Cases: 5
- Agent completed: 5
- Patches produced: 5
- Runtime hard gate: 5/5
- Officially judged: 5
- Resolved: 4 (80.0%)
- Resolved with valid runtime evidence: 4
- Agent behavior findings: 0/5
- KPI verdict: insufficient-evidence
- Task completion: 80.0% (target >= 80%)
- Tool-call operational accuracy: 100.0% (target >= 90%)
- Dead-loop rate: 0.0% (target < 5%)
- KPI evidence gaps: minimum-cases:5/50
- Failure categories: none=5

| Instance | Agent | Resolved | Models | Tools | Protocol failed/blocked | Command nonzero/observed/unknown | Compactions/checks | Tokens in/out | Lifecycle | Findings |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| `django__django-11049` | completed | yes | 17 | 21 | 0/0 | 0/3/0 | 0/16 | 483717/7634 | closed | none |
| `django__django-11815` | completed | yes | 14 | 17 | 0/0 | 0/5/0 | 0/13 | 352734/7114 | closed | none |
| `django__django-12308` | completed | no | 17 | 24 | 0/0 | 0/4/0 | 0/16 | 544114/13505 | closed | none |
| `django__django-12983` | completed | yes | 8 | 11 | 0/0 | 1/4/0 | 0/7 | 136816/3153 | closed | none |
| `django__django-13551` | completed | yes | 10 | 13 | 0/0 | 0/3/0 | 0/9 | 229473/7255 | closed | none |

Correctness comes only from the official SWE-bench harness. Runtime closure is an evidence-validity hard gate and never substitutes for correctness.

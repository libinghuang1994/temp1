# dicode-agent-kpi-swebench-lite-50-v1

- Dataset: `princeton-nlp/SWE-bench_Lite`
- Suite SHA-256: `76ca17ce3f7524f58d84e0b4cba501b4d548e4271a49b81513109f69b280774e`
- Runner SHA-256: `055716aee1a21510cba8ae03e417b9eb9569074e4d4c6910e8512e4605127387`
- Repository: `5f2010f712af99b944a89dd2de2fd83062523c4d` (dirty)
- Harness: `swebench 4.1.0`, `datasets 5.0.1`
- Cases: 5
- Agent completed: 5
- Patches produced: 5
- Runtime hard gate: 5/5
- Officially judged: 5
- Resolved: 4 (80.0%)
- Resolved with valid runtime evidence: 4
- Agent behavior findings: 2/5
- KPI verdict: insufficient-evidence
- Task completion: 80.0% (target >= 80%)
- Tool-call operational accuracy: 100.0% (target >= 90%)
- Dead-loop rate: 0.0% (target < 5%)
- KPI evidence gaps: minimum-cases:5/50
- Failure categories: none=3, model-request-limit=2

| Instance | Agent | Resolved | Models | Tools | Protocol failed/blocked | Command nonzero/observed/unknown | Compactions/checks | Tokens in/out | Lifecycle | Findings |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| `django__django-14017` | completed | yes | 16 | 23 | 0/0 | 0/7/0 | 0/15 | 627142/23787 | closed | none |
| `django__django-14787` | completed | yes | 24 | 32 | 0/0 | 2/16/1 | 0/23 | 1278464/40102 | closed | none |
| `django__django-15388` | completed | yes | 24 | 29 | 0/0 | 2/10/0 | 0/23 | 1025662/19314 | closed | none |
| `django__django-15902` | completed | no | 34 | 49 | 0/0 | 1/15/0 | 0/33 | 2171161/40509 | closed | model-request-limit |
| `django__django-16816` | completed | yes | 34 | 38 | 0/0 | 1/9/0 | 0/33 | 1972402/45769 | closed | model-request-limit |

Correctness comes only from the official SWE-bench harness. Runtime closure is an evidence-validity hard gate and never substitutes for correctness.

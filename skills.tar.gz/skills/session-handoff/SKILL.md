---
name: session-handoff
description: Create comprehensive session handoff documents and changelogs after completing multi-step engineering work, ensuring seamless continuation in a fresh session. Use when finishing a work session that involved code changes, deployments, config updates, or multi-round iterations, and the user asks to record progress, write a handoff, summarize work, or ensure continuity. Also use when the user says "记录进展", "写交接", "总结", or asks to verify a handoff is complete enough.
---

# Session Handoff

Create self-contained handoff documents that let a fresh Codex instance resume work with zero context loss.

## Core Principle

A handoff must answer: "If I start completely fresh tomorrow, can I pick up exactly where I left off?" If any answer is "I'd have to guess", the handoff is incomplete.

## Handoff vs Changelog — 职责边界

Two documents serve different purposes. Do not duplicate content between them:

- **Handoff**（`/workspace/handoff-{date}-sess{N}.md`）：面向"恢复工作"。回答"当前状态是什么、下一步做什么、怎么操作"。重点是**当前快照**：部署状态、评测结果、操作命令、回退方案、待办事项。每个文件只写一句话级别的改动描述，不展开代码差异。
- **Changelog**（`/workspace/changelog-{date}.md`）：面向"理解演进"。回答"每个版本改了什么、为什么改、前后代码对比"。重点是**版本间差异**：每个改动的 before→after 代码内容、根因分析、备份文件位置。如果只有一轮迭代无需 changelog。

一句话区分：handoff 写"现在在哪、往哪走"，changelog 写"怎么走到这里的"。

## Workflow

### 1. Recover Context

Read prior handoff docs and changelogs to understand what was done before:

```bash
ls /workspace/handoff*.md /workspace/changelog*.md 2>/dev/null
cat <latest-handoff>.md
```

Verify current state matches what the handoff claims:
- `git diff --stat` for uncommitted code changes
- `docker ps` for running containers
- `docker images` for available images
- Check config files / backups exist where claimed

### 2. Write the Handoff Document

Create or update `/workspace/handoff-{date}-sess{N}.md`. Use the template in `assets/handoff-template.md`.

Every handoff must contain these sections:

- **一句话状态**: What was done, what's the current state
- **环境注意事项**: Environment-specific gotchas that caused failures or wasted time (e.g. Docker needs sudo, HF cache is read-only, ports conflict). List anything a fresh session would need to know before running commands.
- **工作内容**: Each change with file path, line count, and what changed (one paragraph per change, not full code diffs — those go in changelog)
- **改动文件清单**: Table grouped by repo/system. Mark each file's **生效方式** (live immediately vs needs deploy). This is critical: a fresh session must know which changes are already active and which need a build/restart.
- **运行环境与部署状态**: Current runtime state (Docker images, containers, remote configs). Adapt to actual tech stack — don't force Docker/Nacos rows if they don't apply.
- **评测结果**: Metrics table (before/after), per-instance breakdown
- **评测结果路径**: Exact directories containing eval outputs
- **操作命令速查**: Copy-pasteable commands for environment startup, build, deploy, config update, eval run, log verification. Include env vars from section 二.
- **回退方案**: Step-by-step commands to revert to previous state
- **决策记录**: Key design decisions and why alternatives were rejected. Record the "why", not just the "what".
- **待办 / 后续方向**: What remains, what to improve, known issues
- **关键路径**: Quick-reference table of all important file paths, URLs, container names

### 3. Write the Changelog (for multi-round iterations)

If work spanned multiple iterations (e.g., v1→v2), create `/workspace/changelog-{date}.md`. Use `assets/changelog-template.md`.

For each version transition, document per-change:
- File path and change amount
- What the previous version had (include actual code/content)
- What the new version has (include actual code/content)
- Why it changed (root cause → fix)
- Backup file location (if config/source was overwritten)

### 4. Verify Completeness

Run the verification script:

```bash
python3 /workspace/skills/session-handoff/scripts/verify_handoff.py /workspace/handoff-{date}-sess{N}.md
```

The script checks:
- All required sections present
- All referenced file paths exist on disk
- Docker images mentioned exist (with `sudo docker` fallback)
- Eval result directories are complete (summaries + streams + harness + predictions)
- Cross-references to changelog and prior handoff docs are valid
- **State consistency**: HEAD hash in handoff matches actual `git rev-parse`, resolve_rate matches actual `summary.json`, running container image tag matches handoff

Manual checklist — confirm each item exists and is accurate:

- [ ] All modified files listed with correct git status
- [ ] Each file's 生效方式 (live vs needs deploy) is marked correctly
- [ ] All Docker images listed (current + all prior versions for rollback)
- [ ] All config backups exist at stated paths (`test -f` each)
- [ ] All eval result directories complete (summaries + streams + harness + predictions)
- [ ] Deployed container running the stated image tag
- [ ] Nacos/remote config matches stated version
- [ ] Environment gotchas from this session are captured in section 二
- [ ] Operation commands tested or verified against current environment (including env vars)
- [ ] Rollback commands reference correct backup files and image tags
- [ ] Changelog referenced from handoff (if changelog exists)
- [ ] Prior handoff docs referenced
- [ ] Key design decisions recorded with rationale (not just outcome)

### 5. Persist Backups

Move any temp backups to persistent workspace paths:

```bash
# Example: Nacos config backups from /tmp to workspace
cp /tmp/agent_rules_*.yaml /workspace/<project>/config/
```

Save version-specific source snapshots if a file was overwritten between iterations:

```bash
# Example: v1 env_injector.go was overwritten by v2
cp <v1-content> /workspace/<project>/config/env_injector_v1.go.bak
```

## Key Guidelines

- **Paths over descriptions**: Every file, image, container, URL must have its exact path written. "Nacos config backup" is useless; `/workspace/costrict-server/config/chat-rag/agent_rules_nacos_v2.yaml` is useful.
- **Commands over prose**: Don't describe what to do — write the exact copy-pasteable command.
- **Verify, don't assume**: After writing "image v1.5.22 exists", run `docker images | grep v1.5.22` to confirm. After writing "resolve_rate 90%", check the actual `summary.json`.
- **Environment gotchas are first-class**: If you hit a permission error, missing dependency, or environment quirk during the session, it goes in section 二. These are the things that waste the most time in a fresh session.
- **Mark 生效方式 explicitly**: For every file change, state whether it's already active (live) or requires deployment (build image, restart service, update config). A fresh session must not assume a code change is live.
- **Three versions of truth**: For each config/source that changed across iterations, keep backups of all versions (before, v1, v2) in persistent storage.
- **Cross-reference**: Handoff points to changelog; changelog points to backup files; both point to prior docs.
- **Decision rationale**: Record why a design choice was made and why alternatives were rejected, not just what was chosen. Future iterations need the reasoning to avoid re-litigating decisions.

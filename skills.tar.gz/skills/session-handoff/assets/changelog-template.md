# 改造变更日志：Before → v1 → v2

> 日期：{date}
> 记录每一轮迭代相对于前一版本的具体改动

---

## Before（原始版本）

**镜像**：`{image:tag}`
**配置**：{config state}
**代码**：`{repo}` HEAD `{hash}`，零改动

**问题**：
- {problem 1}
- {problem 2}

---

## v1 相对于 Before 的改动

### v1-G1：{change name}

**文件**：`{file path}`
**改动**：+{N} 行

{What was added/changed. Before had X, v1 adds Y.}

### v1-G2：{change name}

{Same structure for each v1 change}

### v1 评测结果

| 指标 | Before | v1 | 变化 |
|------|--------|-----|------|
| {metric} | {val} | {val} | {delta} |

---

## v2 相对于 v1 的改动

### v2-G1：{change name}

**文件**：`{file path}`

**v1 → v2 差异**：

v1 content:
```
{v1 code/content}
```

v2 content:
```
{v2 code/content}
```

**改动原因**：{why}

**v1 版备份**：`{backup path}`

### v2-G2：{change name}

{Same structure for each v2 change}

### v2 评测结果

| 指标 | v1 | v2 | 变化 |
|------|-----|-----|------|
| {metric} | {val} | {val} | {delta} |

---

## 文件级改动汇总

### `{file path}`（{which version added, which modified}）
- v1：+{N} 行（{what}）
- v2 变更：{what changed}

### `{file path}`（{version history}）
- {version}: {changes}

---

## 配置备份文件

| 文件 | 内容 | 路径 |
|------|------|------|
| {name} | {version} | `{path}` |
| {name} | {version} | `{path}` |

## Docker 镜像

| 镜像 | 版本 | 状态 |
|------|------|------|
| `{image:tag}` | {version} | {status} |

# {Project} — 交接文档（会话 {N}：{session-summary}）

> 日期：{date}
> 目标：{objective}
> 前序文档：`{prior-handoff-docs}`
> **详细变更日志**：`/workspace/changelog-{date}.md`（{what changelog contains}）
> 本次状态：**{one-line outcome}**

---

## 一、一句话状态

{2-3 sentences: what was done, how many iterations, key metrics before→after, current state}

---

## 二、环境注意事项

{Environment-specific gotchas that caused failures or wasted time. List anything a fresh session would need to know before running commands.}

- **{gotcha 1}**：{detail, e.g. "Docker daemon needs `sudo dockerd &` — no systemd in this env"}
- **{gotcha 2}**：{detail, e.g. "HF cache dir is read-only, must set HF_DATASETS_OFFLINE=1 and redirect to /tmp"}
- **{gotcha 3}**：{detail}

---

## 三、工作内容

### {Change 1 name}

**文件**：`{file path}` {function/section}
**改动**：+{N} 行

{What changed, before→after, why}

### {Change 2 name}

{Same structure for each change}

---

## 四、改动文件清单

{If changes span multiple repos/systems, group by repo. Mark which changes are live (effective immediately) vs which need deployment (require build/restart to take effect).}

#### {Repo/System 1 name}（{live | needs deploy}）

| 文件 | 改动量 | 改造 | 生效方式 | 状态 |
|------|--------|------|----------|------|
| `{path}` | +{N} 行 | {which change} | {直接生效 / 需构建镜像 / 需重启服务} | git tracked, modified |
| `{path}` | 新建 ~{N} 行 | {which change} | {同上} | untracked (new file) |

#### {Repo/System 2 name}（{live | needs deploy}）

| 文件 | 改动量 | 改造 | 生效方式 | 状态 |
|------|--------|------|----------|------|
| `{path}` | {what changed} | {which change} | {同上} | {git status} |

**Git 状态**：改动均未提交（`{repo}` 仓库，HEAD `{hash}`）。

---

## 五、运行环境与部署状态

{Describe the current runtime state. Adapt the table to your actual tech stack — Docker, Kubernetes, bare metal, serverless, etc. Remove rows that don't apply.}

| 组件 | 状态 |
|------|------|
| {Runtime image（当前）} | `{image:tag}` |
| {Prior version image} | `{image:tag}`（保留可回退） |
| {Container/Service} | `{name}` Up, 使用 {version} |
| {Remote config} | {config name} 已更新为 {version} |
| {Config console} | `{url}`（{credentials}） |

---

## 六、评测结果

### {N}.1 {N-round}对比总表

| 指标 | Before | After-v1 | After-v2 | 目标 |
|------|--------|----------|----------|------|
| {metric} | {val} | {val} | **{val}** | {target} {✅/❌} |

### {N}.2 逐实例对比

| Instance | Before | After-v1 | After-v2 |
|----------|:---:|:---:|:---:|
| {instance} | {✓/✗} | {✓/✗} | {✓/✗} |

---

## 七、评测结果路径

| 轮次 | 结果目录 |
|------|---------|
| Before | `/workspace/{eval-dir}/results/{run-dir}/` |
| After-v{N} | `/workspace/{eval-dir}/results/{run-dir}/` |

---

## 八、操作命令速查

### {N}.1 环境启动
```bash
{exact commands, including any env vars or prerequisites from section 二}
```

### {N}.2 构建/编译
```bash
{exact commands}
```

### {N}.3 部署/重启
```bash
{exact commands}
```

### {N}.4 更新配置
```bash
{exact commands}
```

### {N}.5 跑评测
```bash
{exact commands for all modes}
```

### {N}.6 验证改造是否生效
```bash
{grep commands for log verification}
```

---

## 九、回退方案

{Provide step-by-step rollback commands. Group by component if multiple systems are involved.}

```bash
# 1. 回退配置
{exact commands}

# 2. 回退代码
{exact commands}

# 3. 回退镜像/运行时
{exact commands}
```

---

## 十、决策记录

{Record key design decisions and why alternatives were rejected. This helps future iterations understand the reasoning, not just the outcome.}

- **{decision 1}**：{what was chosen}。{why}。替代方案 {X} 被否因为 {reason}。
- **{decision 2}**：{what was chosen}。{why}。替代方案 {X} 被否因为 {reason}。

---

## 十一、待办 / 后续方向

1. **{item}**：{detail}
2. **{item}**：{detail}

---

## 十二、关键路径速查

| 类别 | 路径 |
|------|------|
| 代码仓库 | `{path}` |
| 部署目录 | `{path}` |
| 评测系统 | `{path}` |
| 变更日志 | `{path}` |
| 配置备份 | `{paths for all versions}` |
| 当前镜像/运行时 | `{image:tag}` |
| 前序文档 | `{paths}` |

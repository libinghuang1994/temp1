#!/usr/bin/env python3
"""Verify that a handoff document is complete enough for seamless continuation.

Usage:
    python3 verify_handoff.py /workspace/handoff-XXXX-sessN.md

Checks:
  1. All required sections present
  2. All file paths mentioned exist on disk
  3. Docker images mentioned exist (with sudo fallback)
  4. Eval result directories are complete
  5. Cross-references to changelog/prior docs are valid
  6. State consistency: git diff line counts, resolve_rate, container image tag
"""

import json
import os
import re
import subprocess
import sys
from pathlib import Path

REQUIRED_SECTIONS = [
    "一句话状态",
    "环境注意事项",
    "改动文件清单",
    "部署状态",
    "评测结果",
    "结果路径",
    "操作命令",
    "回退",
    "决策记录",
    "待办",
    "关键路径",
]


def check_sections(content):
    """Check that all required sections are present."""
    missing = []
    for section in REQUIRED_SECTIONS:
        if section not in content:
            missing.append(section)
    return missing


def extract_paths(content):
    """Extract file paths from markdown code spans."""
    paths = set()
    for m in re.finditer(r'`(/[^`\s|]+)`', content):
        paths.add(m.group(1))
    for m in re.finditer(r'[│|]\s*`(/[^`]+)`', content):
        paths.add(m.group(1))
    return paths


def check_paths(paths):
    """Check which paths exist and which don't."""
    existing = []
    missing = []
    for p in sorted(paths):
        if any(ext in p for ext in ['.go:', '.py:', '.ts:', '.yaml:', '.md:']):
            p = p.split(':')[0]
        if re.search(r'#L\d+', p):
            p = re.sub(r'#L\d+.*', '', p)
        p = p.rstrip('/')
        if not p.startswith('/'):
            continue
        if '://' in p:
            continue
        if Path(p).exists():
            existing.append(p)
        else:
            missing.append(p)
    return existing, missing


def _run_docker_images():
    """Try docker images, fall back to sudo docker images."""
    for cmd in (['docker', 'images'], ['sudo', 'docker', 'images']):
        try:
            result = subprocess.run(
                cmd + ['--format', '{{.Repository}}:{{.Tag}}'],
                capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0 and result.stdout.strip():
                return set(result.stdout.strip().split('\n'))
        except Exception:
            continue
    return None


def extract_docker_images(content):
    """Extract docker image tags mentioned (format: repo:tag in backticks)."""
    images = set()
    for m in re.finditer(r'`([a-z0-9]+/[a-z0-9_.-]+:[a-z0-9_.-]+)`', content):
        images.add(m.group(1))
    return images


def check_docker_images(images):
    """Check which docker images exist, with sudo fallback."""
    if not images:
        return [], [], False

    existing_images = _run_docker_images()
    if existing_images is None:
        return [], list(images), True  # skip_flag = True

    existing = []
    missing = []
    for img in sorted(images):
        if img in existing_images:
            existing.append(img)
        else:
            missing.append(img)
    return existing, missing, False


def extract_eval_dirs(content):
    """Extract eval result directories."""
    dirs = set()
    for m in re.finditer(r'`(/workspace/[^`]*results/[^`/]+)`', content):
        dirs.add(m.group(1))
    return dirs


def check_eval_dirs(dirs):
    """Check eval result directories for completeness."""
    results = []
    for d in sorted(dirs):
        base = Path(d)
        if not base.exists():
            results.append((d, "MISSING", 0, 0, False))
            continue
        summaries = list((base / 'agent').glob('*/summary.json')) if (base / 'agent').exists() else []
        harness = list((base / 'harness' / 'instance_reports').glob('*.json')) if (base / 'harness' / 'instance_reports').exists() else []
        preds = (base / 'predictions.jsonl').exists()
        status = "OK" if summaries and preds else "INCOMPLETE"
        results.append((d, status, len(summaries), len(harness), preds))
    return results


def check_cross_refs(content, handoff_path):
    """Check that cross-references to other docs are valid."""
    refs = []
    for m in re.finditer(r'`(/workspace/changelog[^`]+\.md)`', content):
        p = m.group(1)
        exists = Path(p).exists()
        refs.append((p, "changelog", exists))
    for m in re.finditer(r'`(/workspace/handoff[^`]+\.md)`', content):
        p = m.group(1)
        if p == str(handoff_path):
            continue
        exists = Path(p).exists()
        refs.append((p, "handoff", exists))
    return refs


def check_git_diff_consistency(content):
    """Check that HEAD hashes mentioned in handoff match actual repo state.

    Only checks repos that are explicitly mentioned alongside a HEAD hash,
    to avoid false positives from unrelated repos on the same machine.
    """
    issues = []
    passes = []

    # Find all HEAD hash mentions with nearby repo path
    # Pattern: repo path + HEAD hash on same or nearby line
    head_mentions = []
    for m in re.finditer(r'HEAD\s+`?([0-9a-f]{7,8})`?', content):
        claimed_head = m.group(1)
        # Find the closest repo path before this HEAD mention
        text_before = content[:m.start()]
        # Look for /workspace/... paths in the last 500 chars before HEAD
        nearby = text_before[-500:] if len(text_before) > 500 else text_before
        repo_found = None
        for pm in re.finditer(r'`(/workspace/[^`\s|]+)`', nearby):
            p = pm.group(1)
            current = Path(p)
            while current != current.parent:
                if (current / '.git').exists():
                    repo_found = str(current)
                    break
                current = current.parent
        if repo_found:
            head_mentions.append((repo_found, claimed_head))

    for repo, claimed_head in head_mentions:
        try:
            result = subprocess.run(
                ['git', 'rev-parse', '--short', 'HEAD'],
                capture_output=True, text=True, timeout=5, cwd=repo
            )
            if result.returncode == 0:
                actual_head = result.stdout.strip()
                if actual_head == claimed_head:
                    passes.append(f"HEAD hash matches: {claimed_head} ({repo})")
                else:
                    issues.append(f"HEAD mismatch: handoff says {claimed_head}, actual is {actual_head} ({repo})")
        except Exception:
            pass

    return passes, issues


def check_resolve_rate_consistency(content):
    """Check that resolve_rate mentioned in handoff matches actual summary.json."""
    issues = []
    passes = []

    # Find eval result directories mentioned
    eval_dirs = extract_eval_dirs(content)
    for d in eval_dirs:
        base = Path(d)
        summary_file = base / 'summary.json'
        if not summary_file.exists():
            continue

        try:
            summary = json.loads(summary_file.read_text())
        except Exception:
            continue

        actual_resolved = summary.get('metrics', {}).get('resolved', '?')
        actual_total = summary.get('metrics', {}).get('total_instances', '?')

        # Look for "N/10" or "resolved=N/..." patterns near this dir name in the handoff
        dir_name = base.name
        # Find lines mentioning this dir
        for line in content.split('\n'):
            if dir_name in line:
                # Look for resolve patterns like "8/10" or "9/10"
                match = re.search(r'(\d+)/(\d+)', line)
                if match:
                    claimed_resolved = int(match.group(1))
                    claimed_total = int(match.group(2))
                    if claimed_total == actual_total and claimed_resolved == actual_resolved:
                        passes.append(f"resolve_rate matches for {dir_name}: {actual_resolved}/{actual_total}")
                    elif claimed_total == actual_total:
                        issues.append(f"resolve_rate mismatch for {dir_name}: handoff says {claimed_resolved}/{claimed_total}, actual is {actual_resolved}/{actual_total}")
                break

    return passes, issues


def check_container_image_consistency(content):
    """Check that running containers mentioned in handoff use the stated image tag.

    Only checks containers whose name AND image tag are both mentioned in the
    handoff, to avoid false positives from infrastructure containers (redis,
    nacos, etc.) that the handoff doesn't track.
    """
    issues = []
    passes = []

    # Try to get running containers
    for cmd in (['docker', 'ps'], ['sudo', 'docker', 'ps']):
        try:
            result = subprocess.run(
                cmd + ['--format', '{{.Names}} {{.Image}} {{.Status}}'],
                capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0 and result.stdout.strip():
                containers = result.stdout.strip().split('\n')
                break
        except Exception:
            continue
    else:
        return passes, issues  # Can't check, skip

    # Only check containers that are mentioned in the handoff alongside an image tag
    # Extract all image tags mentioned in the handoff
    mentioned_images = set()
    for m in re.finditer(r'`([a-z0-9]+/[a-z0-9_.-]+:[a-z0-9_.-]+)`', content):
        mentioned_images.add(m.group(1))

    for line in containers:
        parts = line.split()
        if len(parts) < 3:
            continue
        name, image = parts[0], parts[1]
        # Only check if the container name is mentioned AND at least one
        # image tag from the same repo is mentioned in the handoff
        if name in content:
            # Check if any image from the same repo is mentioned
            repo_prefix = image.split(':')[0] if ':' in image else image
            repo_mentioned = any(img.startswith(repo_prefix) for img in mentioned_images)
            if repo_mentioned:
                if image in content:
                    passes.append(f"Container {name} running {image} (matches handoff)")
                else:
                    issues.append(f"Container {name} is running image {image}, but this tag is not mentioned in handoff")

    return passes, issues


def main():
    if len(sys.argv) < 2:
        print("Usage: verify_handoff.py <handoff.md>")
        sys.exit(1)

    handoff_path = Path(sys.argv[1])
    if not handoff_path.exists():
        print(f"ERROR: Handoff file not found: {handoff_path}")
        sys.exit(1)

    content = handoff_path.read_text()
    issues = []
    passes = []

    # 1. Check sections
    missing_sections = check_sections(content)
    if missing_sections:
        issues.append(f"Missing sections: {', '.join(missing_sections)}")
    else:
        passes.append("All required sections present")

    # 2. Check file paths
    paths = extract_paths(content)
    existing, missing = check_paths(paths)
    real_missing = [p for p in missing if not any(x in p for x in ['sed', 'curl', 'grep', 'docker', 'python', 'bash', 'echo', 'cat '])]
    if real_missing:
        issues.append(f"Paths mentioned but not found ({len(real_missing)}):")
        for p in real_missing[:10]:
            issues.append(f"  ✗ {p}")
    else:
        passes.append(f"All {len(existing)} referenced paths exist")

    # 3. Check docker images
    images = extract_docker_images(content)
    if images:
        existing_imgs, missing_imgs, skipped = check_docker_images(images)
        if skipped:
            passes.append(f"Docker image check skipped (no docker access, {len(images)} images mentioned)")
        elif missing_imgs:
            issues.append(f"Docker images not found: {', '.join(missing_imgs)}")
        else:
            passes.append(f"All {len(existing_imgs)} Docker images exist")

    # 4. Check eval dirs
    eval_dirs = extract_eval_dirs(content)
    if eval_dirs:
        eval_results = check_eval_dirs(eval_dirs)
        for d, status, s, h, p in eval_results:
            if status == "MISSING":
                issues.append(f"Eval dir missing: {d}")
            elif status == "INCOMPLETE":
                issues.append(f"Eval dir incomplete: {d} (summaries={s}, harness={h}, predictions={p})")
            else:
                passes.append(f"Eval dir complete: {d} ({s} summaries, {h} harness, predictions={'yes' if p else 'no'})")

    # 5. Check cross-references
    refs = check_cross_refs(content, handoff_path)
    for p, rtype, exists in refs:
        if exists:
            passes.append(f"Cross-ref valid: {p}")
        else:
            issues.append(f"Cross-ref broken: {p} ({rtype})")

    # 6. State consistency checks
    git_passes, git_issues = check_git_diff_consistency(content)
    passes.extend(git_passes)
    issues.extend(git_issues)

    resolve_passes, resolve_issues = check_resolve_rate_consistency(content)
    passes.extend(resolve_passes)
    issues.extend(resolve_issues)

    container_passes, container_issues = check_container_image_consistency(content)
    passes.extend(container_passes)
    issues.extend(container_issues)

    # Print results
    print(f"=== Handoff Verification: {handoff_path.name} ===\n")
    if passes:
        print(f"✅ Passed ({len(passes)}):")
        for p in passes:
            print(f"  {p}")
    if issues:
        print(f"\n❌ Issues ({len(issues)}):")
        for i in issues:
            print(f"  {i}")
        print(f"\n⚠️  {len(issues)} issue(s) need attention before handoff is complete.")
        sys.exit(1)
    else:
        print(f"\n✅ Handoff is complete and verified!")
        sys.exit(0)


if __name__ == '__main__':
    main()
